import { Component } from "@angular/core";

@Component({
    selector: "show",
    templateUrl: "show.component.html"
})
export class Showcomponent{

    
}